from openai import OpenAI
import os
import json


def get_current_key():
    cwd = os.getcwd()
    # Go back two directories
    grandparent_dir = os.path.dirname(os.path.dirname(cwd))
    config_path = os.path.join(grandparent_dir, 'config.json')
    with open(config_path) as file:
        data = json.load(file)
    return data["api-key"]



client = OpenAI(
    api_key=get_current_key(),
    base_url="https://api.aimlapi.com",
)


def chat_with_client(messages_log):
    response = client.chat.completions.create(
        model="Open-Orca/Mistral-7B-OpenOrca",
        messages=messages_log,
    )

    message = response.choices[0].message.content
    return message

