from chatmanager import *
import json

def get_mute_list(user):
	chat_log = get_full_chat_log(user)
	chats = []
	for chat in chat_log:
		new_item = {
			"username" : chat["username"],
			"mute_status" : chat["muted"]
		}
		chats.append(new_item)
	return chats

def toggle_mute_user(user, username):
	toggle_mute(username, user)


print(get_mute_list(1))